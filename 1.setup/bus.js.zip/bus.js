exports.main = function(event, context, callback)
{
  console.log("hello");
}

